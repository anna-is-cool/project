package com.example.mytime.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.mytime.DatabaseQuotes;
import com.example.mytime.Quote;
import com.example.mytime.R;

public class MotivationFragment extends Fragment {
    private View view;
    public DatabaseQuotes db;
    Button button;
    TextView quote;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_gallery, container, false);
        button = (Button) view.findViewById(R.id.button2);
        quote = (TextView) view.findViewById(R.id.textView2);
        db = new DatabaseQuotes(getActivity());
        db.addQuote(new Quote(1, "Your limitation—it’s only your imagination."));
        db.addQuote(new Quote(2, "Push yourself, because no one else is going to do it for you."));
        db.addQuote(new Quote(3, "Sometimes later becomes never. Do it now."));
        db.addQuote(new Quote(4, "Great things never come from comfort zones."));
        db.addQuote(new Quote(5,"Dream it. Wish it. Do it."));
        db.addQuote(new Quote(6, "Success doesn’t just find you. You have to go out and get it."));
        db.addQuote(new Quote(7, "The harder you work for something, the greater you’ll feel when you achieve it."));
        db.addQuote(new Quote(8, "Dream bigger. Do bigger."));
        db.addQuote(new Quote(9,"Don’t stop when you’re tired. Stop when you’re done."));
        db.addQuote(new Quote(10, "Wake up with determination. Go to bed with satisfaction."));
        db.addQuote(new Quote(11,"Do something today that your future self will thank you for."));
        db.addQuote(new Quote(12, "Little things make big days."));
        db.addQuote(new Quote(13, "It’s going to be hard, but hard does not mean impossible."));
        db.addQuote(new Quote(14, "Don’t wait for opportunity. Create it."));
        db.addQuote(new Quote(15, "Sometimes we’re tested not to show our weaknesses, but to discover our strengths."));
        db.addQuote(new Quote(16, "The key to success is to focus on goals, not obstacles."));
        db.addQuote(new Quote(17, "Dream it. Believe it. Build it."));


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int random = 1 + (int) (Math.random() * 18);
                quote.setText(db.getQuote(random).getQuotee());
            }
        });
        return view;
    }
}