package com.example.mytime.ui.home;

import android.database.CursorIndexOutOfBoundsException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.viewpager.widget.ViewPager;

import com.example.mytime.DatabaseHandler;
import com.example.mytime.R;

public class PlansFragment extends Fragment {
    ViewPager viewPager;

    private View view;
    EditText planName;
    CheckBox check1, check2, check3, check4, check5, check6, check7, check8, check9,
            check10, check11, check12, check13, check14, check15;
    Button button;

    DatabaseHandler db;

    int i = 1;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);

        planName=(EditText)view.findViewById(R.id.planName);
        button=(Button)view.findViewById(R.id.button);
        check1=(CheckBox) view.findViewById(R.id.checkBox);
        check2=(CheckBox) view.findViewById(R.id.checkBox2);
        check3=(CheckBox) view.findViewById(R.id.checkBox3);
        check4=(CheckBox) view.findViewById(R.id.checkBox4);
        check5=(CheckBox) view.findViewById(R.id.checkBox5);
        check6=(CheckBox) view.findViewById(R.id.checkBox6);
        check7=(CheckBox) view.findViewById(R.id.checkBox7);
        check8=(CheckBox) view.findViewById(R.id.checkBox8);
        check9=(CheckBox) view.findViewById(R.id.checkBox9);
        check10=(CheckBox) view.findViewById(R.id.checkBox10);
        check11=(CheckBox) view.findViewById(R.id.checkBox11);
        check12=(CheckBox) view.findViewById(R.id.checkBox12);
        check13=(CheckBox) view.findViewById(R.id.checkBox13);
        check14=(CheckBox) view.findViewById(R.id.checkBox14);
        check15=(CheckBox) view.findViewById(R.id.checkBox15);



        db = new DatabaseHandler(getActivity());

        try {
            check1.setText(db.select(i).getPlanName());
            Toast.makeText(getActivity(), "got it! " , Toast.LENGTH_SHORT).show();
        }catch(CursorIndexOutOfBoundsException e){
            check1.setText("");
        }
        try {
            check2.setText(db.select(i + 1).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check2.setText("");}
        try {
            check3.setText(db.select(i +2).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check3.setText("");}
        try {
            check4.setText(db.select(i + 3).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check4.setText("");}
        try {
            check5.setText(db.select(i + 4).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check5.setText("");}
        try {
            check6.setText(db.select(i + 5).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check6.setText("");}
        try {
            check7.setText(db.select(i + 6).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check7.setText("");}
        try {
            check8.setText(db.select(i + 7).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check8.setText("");}
        try {
            check9.setText(db.select(i + 8).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check9.setText("");}
        try {
            check10.setText(db.select(i + 9).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check10.setText("");}
        try {
            check11.setText(db.select(i + 10).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check11.setText("");}
        try {
            check12.setText(db.select(i + 11).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check12.setText("");}
        try {
            check13.setText(db.select(i + 12).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check13.setText("");}
        try {
            check14.setText(db.select(i + 13).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check14.setText("");}
        try {
            check15.setText(db.select(i + 14).getPlanName());
        }catch(CursorIndexOutOfBoundsException e){
            check15.setText("");}

        check1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check1.isChecked()){
                    try {
                        db.delete(i);
                        check1.setText("");
                        i = i+1;
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check1.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });
        check2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check2.isChecked()){
                    try {
                        db.delete(i+1);
                        check2.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check2.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check3.isChecked()){
                    try {
                        db.delete(i+2);
                        check3.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check3.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check4.isChecked()){
                    try {
                        db.delete(i+3);
                        check4.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check4.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check5.isChecked()){
                    try {
                        db.delete(i+4);
                        check5.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check5.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check6.isChecked()){
                    try {
                        db.delete(i+5);
                        check6.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check6.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check7.isChecked()){
                    try {
                        db.delete(i+6);
                        check7.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check7.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check8.isChecked()){
                    try {
                        db.delete(i+7);
                        check8.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check8.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check9.isChecked()){
                    try {
                        db.delete(i+8);
                        check9.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check9.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check10.isChecked()){
                    try {
                        db.delete(i+9);
                        check10.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check10.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check11.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check11.isChecked()){
                    try {
                        db.delete(i+10);
                        check11.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check11.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });

        check12.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check12.isChecked()){
                    try {
                        db.delete(i+11);
                        check12.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check12.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check13.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check13.isChecked()){
                    try {
                        db.delete(i+12);
                        check13.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check13.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check14.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check14.isChecked()){
                    try {
                        db.delete(i+13);
                        check14.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check14.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        check15.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(check15.isChecked()){
                    try {
                        db.delete(i+14);
                        check15.setText("");
                        Toast.makeText(getActivity(), "Congrats! You've done it!", Toast.LENGTH_SHORT).show();
                        check15.toggle();
                    }catch (CursorIndexOutOfBoundsException e) {
                        Toast.makeText(getActivity(), "Oops...you wanna check nonexistent plan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(check1.getText().toString().equals("")) {
                    db.insert(planName.getText().toString());
                    check1.setText(planName.getText().toString());
                }else{
                    if(check2.getText().toString().equals("")){
                        db.insert(planName.getText().toString());
                        check2.setText(planName.getText().toString());
                    }else{
                        if(check3.getText().toString().equals("")){
                            db.insert(planName.getText().toString());
                            check3.setText(planName.getText().toString());
                        }else{
                            if(check4.getText().toString().equals("")){
                                db.insert(planName.getText().toString());
                                check4.setText(planName.getText().toString());
                            }else{
                                if(check5.getText().toString().equals("")){
                                    db.insert(planName.getText().toString());
                                    check5.setText(planName.getText().toString());
                                }else{
                                    if(check6.getText().toString().equals("")){
                                        db.insert(planName.getText().toString());
                                        check6.setText(planName.getText().toString());
                                    }else{
                                        if(check7.getText().toString().equals("")){
                                            db.insert(planName.getText().toString());
                                            check7.setText(planName.getText().toString());
                                        }else{
                                            if(check8.getText().toString().equals("")){
                                                db.insert(planName.getText().toString());
                                                check8.setText(planName.getText().toString());
                                            }else{
                                                if(check9.getText().toString().equals("")){
                                                    db.insert(planName.getText().toString());
                                                    check9.setText(planName.getText().toString());
                                                }else{
                                                    if(check10.getText().toString().equals("")){
                                                        db.insert(planName.getText().toString());
                                                        check10.setText(planName.getText().toString());
                                                    }else{
                                                        if(check11.getText().toString().equals("")){
                                                            db.insert(planName.getText().toString());
                                                            check11.setText(planName.getText().toString());
                                                        }else{
                                                            if(check12.getText().toString().equals("")){
                                                                db.insert(planName.getText().toString());
                                                                check12.setText(planName.getText().toString());
                                                            }else{
                                                                if(check13.getText().toString().equals("")){
                                                                    db.insert(planName.getText().toString());
                                                                    check13.setText(planName.getText().toString());
                                                                }else{
                                                                    if(check14.getText().toString().equals("")){
                                                                        db.insert(planName.getText().toString());
                                                                        check14.setText(planName.getText().toString());
                                                                    }else{
                                                                        if(check15.getText().toString().equals("")){
                                                                            db.insert(planName.getText().toString());
                                                                            check15.setText(planName.getText().toString());
                                                                        }}}}}}}}}}}}}}}

                Toast.makeText(getActivity(), "Plan added", Toast.LENGTH_SHORT).show();
            }

        });


        return view;
    }

}