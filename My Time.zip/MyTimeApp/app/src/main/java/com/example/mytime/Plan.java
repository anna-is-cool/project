package com.example.mytime;

import java.io.Serializable;

public class Plan implements Serializable {
    private long id;
    private String planName;

    public Plan(){ }

    public Plan(long id, String planName) {
        this.id = id;
        this.planName = planName;
    }

    public long getID() {
        return id;
    }

    public void setID(long id) {
        this.id = id;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }
}
