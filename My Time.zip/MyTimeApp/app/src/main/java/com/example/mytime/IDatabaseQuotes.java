package com.example.mytime;

import java.util.List;

public interface IDatabaseQuotes {
    public void addQuote(Quote quote);
    public Quote getQuote(int id);
    public List<Quote> getAllQuotes();
    public int getQuotesCount();
    public int updateQuote(Quote quote);
    public void deleteQuote(Quote quote);
    public void deleteAll();
}
